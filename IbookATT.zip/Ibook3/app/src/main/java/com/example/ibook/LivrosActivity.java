package com.example.ibook;

import android.os.Bundle;

public class LivrosActivity extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.livros_activity);
    }
}

